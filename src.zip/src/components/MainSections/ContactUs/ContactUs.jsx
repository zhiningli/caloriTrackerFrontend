import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';


function ContactUs() {

    return (
        <MainSectionContainer>
        Hello
        </MainSectionContainer>
    );
}

export default ContactUs;