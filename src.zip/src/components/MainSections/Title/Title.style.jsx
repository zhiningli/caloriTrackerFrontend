import styled from 'styled-components'

export const TitleContainer = styled.div`
    
`

export const TitleLabel = styled.span`

`