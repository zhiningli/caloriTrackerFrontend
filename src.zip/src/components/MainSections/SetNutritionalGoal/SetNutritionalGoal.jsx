import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';

function SetNutritionalGoal() {

    return (
        <MainSectionContainer>
        Hello
        </MainSectionContainer>
    );
}

export default SetNutritionalGoal;