import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';

function AboutApp() {

    return (
        <MainSectionContainer>
            Hello
        </MainSectionContainer>
    );
}

export default AboutApp;