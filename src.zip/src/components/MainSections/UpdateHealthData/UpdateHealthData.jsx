import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';


function UpdateHealthData() {

    return (
        <MainSectionContainer>
        Hello
        </MainSectionContainer>
    );
}

export default UpdateHealthData;