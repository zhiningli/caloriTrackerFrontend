import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';

function EditMeal() {

    return (
        <MainSectionContainer>
        Hello
        </MainSectionContainer>
    );
}

export default EditMeal;