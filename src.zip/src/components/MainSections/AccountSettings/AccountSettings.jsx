import React from 'react';
import { MainSectionContainer } from '../MainSection.sytle';

function AccountSettings() {

    return (
        <MainSectionContainer>
        Hello
        </MainSectionContainer>
    );
}

export default AccountSettings;