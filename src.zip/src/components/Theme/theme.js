const themeColor = {
    colorFurRed: '#A5381F',
    colorSoftWhite: '#F2E8DA',
    colorPandaBrown: '#4B2C20',
    colorDeepTerracotta: '#B34729',
    colorIvory: '#F8F4E6',
    colorDarkChocolate: '#3D2A1B',
};

export default themeColor;
